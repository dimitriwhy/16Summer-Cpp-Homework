#include <bits/stdc++.h>
using namespace std;
#ifndef HITCCCONVERT
#define HITCCCONVERT

extern const char constMark[];
extern char* strsub(char* bytes,int pos,int length);
extern __int64 bytes2long(char *bytes);
extern char* long2bytes(__int64 num);
extern int bytes2int(char *bytes);
extern char* int2bytes(int num);

#endif
